import { BehaviorSubject } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class DataShareService {
questionsType;
setQnType(type) {
  this.questionsType = type;
}
getQnType() {
  return this.questionsType;
}
constructor() { }

}
