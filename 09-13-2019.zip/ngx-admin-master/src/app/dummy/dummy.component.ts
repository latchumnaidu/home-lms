import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'ngx-dummy',
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './dummy.component.html',
  styleUrls: ['./dummy.component.scss'],
})
export class DummyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
