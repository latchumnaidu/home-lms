import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { NbMenuModule, NbIconModule, NbLayoutModule,
     NbCheckboxModule, NbCardModule, NbButtonModule } from '@nebular/theme';

import { ThemeModule } from '../@theme/theme.module';
import { HomeRoutingModule } from './home-routing.module';
import { HomeComponent } from './home.component';
import { MainPageComponent } from './main-page/main-page.component';
import { LoginComponent } from './login/login.component';
import { RouterModule } from '@angular/router';
import { SubscrptionComponent } from './subscrption/subscrption.component';
import { SubscribePlanComponent } from './subscribe-plan/subscribe-plan.component';

@NgModule({
  imports: [
    ThemeModule,
    NbMenuModule,
    HomeRoutingModule,
    NbIconModule,
    NbLayoutModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    NbCheckboxModule,
    NbCardModule,
    NbButtonModule,
  ],
  declarations: [
    HomeComponent,
    MainPageComponent,
    LoginComponent,
    SubscrptionComponent,
    SubscribePlanComponent,
  ],
})
export class HomeModule {
}
