import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-subscribe-plan',
  templateUrl: './subscribe-plan.component.html',
  styleUrls: ['./subscribe-plan.component.scss'],
})
export class SubscribePlanComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
