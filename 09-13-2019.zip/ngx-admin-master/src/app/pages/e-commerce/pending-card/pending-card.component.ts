import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-pending-card',
  templateUrl: './pending-card.component.html',
  styleUrls: ['./pending-card.component.scss'],
})
export class PendingCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
