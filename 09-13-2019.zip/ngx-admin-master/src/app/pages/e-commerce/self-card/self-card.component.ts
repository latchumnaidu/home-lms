import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-self-card',
  templateUrl: './self-card.component.html',
  styleUrls: ['./self-card.component.scss'],
})
export class SelfCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
