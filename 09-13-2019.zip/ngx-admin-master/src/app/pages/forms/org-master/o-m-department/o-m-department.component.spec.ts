import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OMDepartmentComponent } from './o-m-department.component';

describe('OMDepartmentComponent', () => {
  let component: OMDepartmentComponent;
  let fixture: ComponentFixture<OMDepartmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OMDepartmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OMDepartmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
