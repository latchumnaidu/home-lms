import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import {Component, OnInit, ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';

export interface PeriodicElement {
  emp_id: string;
  address: string;
  emp_name: string;
}
const ELEMENT_DATA: PeriodicElement[] = [
 {
    address: 'hr', emp_name : 'hyderabad',
    emp_id: '50038',
  },
  {
     address: 'hr', emp_name : 'hyderabad',
     emp_id: '50012',
   },
   {
     address: 'hr', emp_name : 'kolkatta',
     emp_id: '46515',
   },
   {
     address: 'developer', emp_name : 'hyderabad',
    emp_id: '6565',
   },
   {
     address: 'hr', emp_name : 'vizag',
     emp_id: '410410',
   },
   {
     address: 'network', emp_name : 'pune',
     emp_id: '00012',
   },
];

@Component({
  selector: 'ngx-o-m-department',
  templateUrl: './o-m-department.component.html',
  styleUrls: ['./o-m-department.component.scss'],
})
export class OMDepartmentComponent implements OnInit {
  employeeForm: FormGroup;
  submitted = false;
  displayedColumns: string[] = [
    'emp_id', 'address', 'emp_name',
     'action'];
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  editEmp: boolean;

  constructor( private router: Router,
    private fb: FormBuilder,
    private http: HttpClient ) {
  }

  ngOnInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.inItForm();
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  addLocation() {
    // this.router.navigate(['./pages/forms/master/add-employee']);
    this.editEmp = true;
  }
  inItForm() {
    this.employeeForm = this.fb.group({
      emp_id: ['', Validators.required],
      address: ['', Validators.required],
      emp_name: ['', Validators.required],
      org_code: ['', Validators.required],
      status: ['', Validators.required],
    });
  }
  get form() {
    return this.employeeForm.controls;
  }
  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.employeeForm.invalid) {
        return;
    } else {
      const url = 'http://192.168.0.18/api/owner/register/client/';
      this.http.post(url, this.employeeForm.value).subscribe(res => {
      });
    }
  }
  listLocation() {
    // this.router.navigate(['./pages/forms/master/list-employee']);
    this.editEmp = false;
  }
}
