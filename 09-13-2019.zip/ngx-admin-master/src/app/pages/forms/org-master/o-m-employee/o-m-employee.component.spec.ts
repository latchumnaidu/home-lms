import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OMEmployeeComponent } from './o-m-employee.component';

describe('OMEmployeeComponent', () => {
  let component: OMEmployeeComponent;
  let fixture: ComponentFixture<OMEmployeeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OMEmployeeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OMEmployeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
