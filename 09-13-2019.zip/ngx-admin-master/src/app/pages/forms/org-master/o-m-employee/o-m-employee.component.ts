import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NbDialogService } from '@nebular/theme';
import { HttpClient } from '@angular/common/http';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
export interface PeriodicElement {
  emp_id: string;
  address: string;
  emp_name: string;
  org_code: string;
  status: string;
}
const ELEMENT_DATA: PeriodicElement[] = [
 {
   org_code : 'A123', address: 'hr', emp_name : 'hyderabad', status: 'A',
    emp_id: '50038',
  },
  {
    org_code : 'A123', address: 'hr', emp_name : 'hyderabad', status: 'A',
     emp_id: '50012',
   },
   {
    org_code : 'A123', address: 'hr', emp_name : 'kolkatta', status: 'B',
     emp_id: '46515',
   },
   {
    org_code : 'A123', address: 'developer', emp_name : 'hyderabad', status: 'C',
    emp_id: '6565',
   },
   {
    org_code : 'A123', address: 'hr', emp_name : 'vizag', status: 'D',
     emp_id: '410410',
   },
   {
    org_code : 'A123', address: 'network', emp_name : 'pune', status: 'E',
     emp_id: '00012',
   },
];
@Component({
  selector: 'ngx-o-m-employee',
  templateUrl: './o-m-employee.component.html',
  styleUrls: ['./o-m-employee.component.scss'],
})
export class OMEmployeeComponent implements OnInit {
  employeeForm: FormGroup;
  submitted = false;
  displayedColumns: string[] = [
    'org_code', 'emp_id', 'address', 'emp_name',
      'status', 'action'];
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  addEmp = false;
  constructor(
    private router: Router,
    private dialogService: NbDialogService,
    private fb: FormBuilder,
    private http: HttpClient,
    ) { }

    ngOnInit() {
      this.inItForm();
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }
    inItForm() {
      this.employeeForm = this.fb.group({
        emp_id: ['', Validators.required],
        address: ['', Validators.required],
        emp_name: ['', Validators.required],
        org_code: ['', Validators.required],
        status: ['', Validators.required],
      });
    }
    get form() {
      return this.employeeForm.controls;
    }
    onSubmit() {
      this.submitted = true;
      // stop here if form is invalid
      if (this.employeeForm.invalid) {
          return;
      } else {
        const url = 'http://192.168.0.18/api/owner/register/client/';
        this.http.post(url, this.employeeForm.value).subscribe(res => {
        });
      }
    }
    listLocation() {
      // this.router.navigate(['./pages/forms/master/list-employee']);
      this.addEmp = false;
    }
    applyFilter(filterValue: string) {
      this.dataSource.filter = filterValue.trim().toLowerCase();
      if (this.dataSource.paginator) {
        this.dataSource.paginator.firstPage();
      }
    }
    addLocation() {
      // this.router.navigate(['./pages/forms/master/add-employee']);
      this.addEmp = true;
    }

}
