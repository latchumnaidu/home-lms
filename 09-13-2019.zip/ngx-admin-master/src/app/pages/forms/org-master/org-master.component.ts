import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'ngx-org-master',
  templateUrl: './org-master.component.html',
  styleUrls: ['./org-master.component.scss'],
})
export class OrgMasterComponent implements OnInit {
tabs = [
  {title: 'Org.Location', link: 'location'},
  {title: 'Employee', link: 'employee'},
  {title: 'Department', link: 'department'},
];
  constructor(private router: Router) { }

  ngOnInit() {
  }
  navLocation(url) {
    this.router.navigate(['./pages/forms/master/' +  url]);
  }
}
