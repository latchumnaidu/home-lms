import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AReviewComponent } from './a-review.component';

describe('AReviewComponent', () => {
  let component: AReviewComponent;
  let fixture: ComponentFixture<AReviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AReviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AReviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
