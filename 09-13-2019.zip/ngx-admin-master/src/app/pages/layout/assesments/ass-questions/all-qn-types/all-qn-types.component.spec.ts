import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllQnTypesComponent } from './all-qn-types.component';

describe('AllQnTypesComponent', () => {
  let component: AllQnTypesComponent;
  let fixture: ComponentFixture<AllQnTypesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllQnTypesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllQnTypesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
