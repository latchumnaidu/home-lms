import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssQuestionsComponent } from './ass-questions.component';

describe('AssQuestionsComponent', () => {
  let component: AssQuestionsComponent;
  let fixture: ComponentFixture<AssQuestionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssQuestionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssQuestionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
