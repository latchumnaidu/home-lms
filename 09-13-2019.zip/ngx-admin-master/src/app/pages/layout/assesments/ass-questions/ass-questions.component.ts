import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-ass-questions',
  templateUrl: './ass-questions.component.html',
  styleUrls: ['./ass-questions.component.scss']
})
export class AssQuestionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
