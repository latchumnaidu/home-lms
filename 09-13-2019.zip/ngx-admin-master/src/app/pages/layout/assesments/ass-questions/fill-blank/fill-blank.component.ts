import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-fill-blank',
  templateUrl: './fill-blank.component.html',
  styleUrls: ['./fill-blank.component.scss']
})
export class FillBlankComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
