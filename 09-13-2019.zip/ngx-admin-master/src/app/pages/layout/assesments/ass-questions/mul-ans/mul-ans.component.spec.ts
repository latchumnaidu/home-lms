import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MulAnsComponent } from './mul-ans.component';

describe('MulAnsComponent', () => {
  let component: MulAnsComponent;
  let fixture: ComponentFixture<MulAnsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MulAnsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MulAnsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
