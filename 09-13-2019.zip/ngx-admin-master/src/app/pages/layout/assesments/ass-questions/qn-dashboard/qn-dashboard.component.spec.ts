import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QnDashboardComponent } from './qn-dashboard.component';

describe('QnDashboardComponent', () => {
  let component: QnDashboardComponent;
  let fixture: ComponentFixture<QnDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QnDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QnDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
