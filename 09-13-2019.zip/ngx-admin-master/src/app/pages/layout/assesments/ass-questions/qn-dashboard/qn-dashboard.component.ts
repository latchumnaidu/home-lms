import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataShareService } from '../../../../../data-share.service';

@Component({
  selector: 'ngx-qn-dashboard',
  templateUrl: './qn-dashboard.component.html',
  styleUrls: ['./qn-dashboard.component.scss'],
})
export class QnDashboardComponent implements OnInit {
  selectedOption;
  showAllQns = false;
  constructor(
    private router: Router,
    private dataShare: DataShareService,
    ) { }

  ngOnInit() {
  }
allTypes(type) {
  // this.dataShare.setQnType(type);
  // this.router.navigate(['./pages/layout/assesment/all-qns']);
  this.selectedOption = type;
  this.showAllQns = true;
}
backtoDashboar() {
  this.showAllQns = false;
 }
}
