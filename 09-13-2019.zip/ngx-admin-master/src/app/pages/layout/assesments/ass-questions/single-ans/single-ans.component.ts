import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'ngx-single-ans',
  templateUrl: './single-ans.component.html',
  styleUrls: ['./single-ans.component.scss'],
})
export class SingleAnsComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }
backtoDashboar() {
  this.router.navigate(['./pages/layout/assesment/add-qns/qn-dashboard']);
}
}
