import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-true-false',
  templateUrl: './true-false.component.html',
  styleUrls: ['./true-false.component.scss']
})
export class TrueFalseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
