import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssUsersComponent } from './ass-users.component';

describe('AssUsersComponent', () => {
  let component: AssUsersComponent;
  let fixture: ComponentFixture<AssUsersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssUsersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssUsersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
