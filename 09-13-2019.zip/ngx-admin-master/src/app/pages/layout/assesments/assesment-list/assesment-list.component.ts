import { Component, OnInit, TemplateRef } from '@angular/core';
import { Router } from '@angular/router';
import { NbDialogService } from '@nebular/theme';

@Component({
  selector: 'ngx-assesment-list',
  templateUrl: './assesment-list.component.html',
  styleUrls: ['./assesment-list.component.scss'],
})
export class AssesmentListComponent implements OnInit {

  constructor(
    private router: Router,
    private dialogService: NbDialogService,
    ) { }

  ngOnInit() {
  }
  open(dialog: TemplateRef<any>) {
    this.dialogService.open(dialog, { context: 'Are you sure want to delete?' });
  }
  uploadFile(upload: TemplateRef<any>) {
    this.dialogService.open(upload, { context: 'Are you sure want to delete?' });
  }
  addJob() {
    this.router.navigate(['./pages/layout/assesment/add-assesment']);
  }

}
