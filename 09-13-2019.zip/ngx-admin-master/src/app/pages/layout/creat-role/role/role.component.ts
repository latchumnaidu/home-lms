import { Component, OnInit, TemplateRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { NbDialogService } from '@nebular/theme';

@Component({
  selector: 'ngx-role',
  templateUrl: './role.component.html',
  styleUrls: ['./role.component.scss'],
})
export class RoleComponent implements OnInit {

  creatAccountForm: FormGroup;
  submitted = false;
  constructor(private fb: FormBuilder,
    private http: HttpClient,
    private router: Router,
    private dialogService: NbDialogService) { }

    ngOnInit() {
      this.inItForm();
    }
    inItForm() {
      this.creatAccountForm = this.fb.group({
        first_name: ['', Validators.required],
        last_name: ['', Validators.required],
        email: ['', [Validators.required, Validators.email,
          Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
        org_name: ['', Validators.required],
        org_code: ['', Validators.required],
        head_quart: ['', Validators.required],
        contact_person: ['', Validators.required],
      });
    }
    get form() {
      return this.creatAccountForm.controls;
    }
    onSubmit() {
      this.submitted = true;
      // stop here if form is invalid
      if (this.creatAccountForm.invalid) {
          return;
      } else {
        const url = 'http://192.168.0.18/api/owner/register/client/';
        this.http.post(url, this.creatAccountForm.value).subscribe(res => {
        });
      }
    }
  open(dialog: TemplateRef<any>) {
    this.dialogService.open(dialog, { context: 'Are you sure want to delete?' });
  }
  uploadFile(upload: TemplateRef<any>) {
    this.dialogService.open(upload, { context: 'Are you sure want to delete?' });
  }
  addType(dialog: TemplateRef<any>) {
    this.dialogService.open(dialog, { context: 'Are you sure want to delete?' });
  }

}
