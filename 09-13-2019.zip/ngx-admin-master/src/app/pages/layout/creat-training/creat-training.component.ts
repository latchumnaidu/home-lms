import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-creat-training',
  templateUrl: './creat-training.component.html',
  styleUrls: ['./creat-training.component.scss']
})
export class CreatTrainingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
