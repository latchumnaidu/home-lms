
export abstract class SmartTableData {
  abstract getData(): any[];
}
