import { FormGroup, FormBuilder } from '@angular/forms';
import { Component, OnInit, TemplateRef } from '@angular/core';
import { Router } from '@angular/router';
import { NbDialogService } from '@nebular/theme';
import { DataShareService } from '../../data-share.service';
@Component({
  selector: 'ngx-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  checked = false;
  forgotPsw = false;
  loginForm: FormGroup;
  constructor(
    private router: Router,
    private dialogService: NbDialogService,
    private fb: FormBuilder,
    private dataShare: DataShareService,
  ) { }

  ngOnInit() {
    this.inItForm();
  }
  inItForm() {
    this.loginForm = this.fb.group({
      user_name: '',
      password: '',
    });
  }
  home() {
    this.router.navigate(['./home/main']);
  }
  toggle(checked: boolean) {
    this.checked = checked;
  }
  sigin() {
    const value = this.loginForm.get('user_name').value;
    if (value) {
      // this.dataShare.userName(value);
      sessionStorage.setItem('login_role', value);
      this.router.navigate(['./pages']);
    }
  }
  open(dialog: TemplateRef<any>) {
    this.dialogService.open(dialog, { context: 'Are you sure want to delete?' });
  }
}
