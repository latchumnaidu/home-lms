import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'ngx-subscrption',
  templateUrl: './subscrption.component.html',
  styleUrls: ['./subscrption.component.scss'],
})
export class SubscrptionComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }
  home() {
    this.router.navigate(['./home/main']);
  }
}
