import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-external-card',
  templateUrl: './external-card.component.html',
  styleUrls: ['./external-card.component.scss'],
})
export class ExternalCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
