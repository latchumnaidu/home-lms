import { AddDeptComponent } from './org-master/o-m-department/add-dept/add-dept.component';
import { AddEmployeeComponent } from './org-master/o-m-employee/add-employee/add-employee.component';
import { ListLocationComponent } from './org-master/o-m-location/list-location/list-location.component';
import { AddLocationComponent } from './org-master/o-m-location/add-location/add-location.component';
import { UserRolesComponent } from './user-roles/user-roles.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { FormsComponent } from './forms.component';
import { OrgMasterComponent } from './org-master/org-master.component';
import { OMLocationComponent } from './org-master/o-m-location/o-m-location.component';
import { OMEmployeeComponent } from './org-master/o-m-employee/o-m-employee.component';
import { OMDepartmentComponent } from './org-master/o-m-department/o-m-department.component';
import { ListEmployeeComponent } from './org-master/o-m-employee/list-employee/list-employee.component';
import { ListDeptComponent } from './org-master/o-m-department/list-dept/list-dept.component';


const routes: Routes = [
  {
    path: '',
    component: FormsComponent,
    children: [
      {
        path: 'master',
        component: OrgMasterComponent,
        children: [
          {
            path: '',
            component: OMLocationComponent,
            children: [
              {
                path: 'add-location',
                component: AddLocationComponent,
              },
              {
                path: 'list-location',
                component: ListLocationComponent,
              },
              {
                path: '',
                redirectTo: 'list-location',
                pathMatch: 'full',
              },
            ],
          },
          {
            path: '',
            component: OMEmployeeComponent,
            children: [
              {
                path: 'add-employee',
                component: AddEmployeeComponent,
              },
              {
                path : 'list-employee',
                component: ListEmployeeComponent,
              },
              {
                path : '',
                redirectTo: 'list-employee',
                pathMatch: 'full',
              },
            ],
          },
          {
            path : 'department',
            component: OMDepartmentComponent,
            children: [
              {
                path: 'add-dept',
                component: AddDeptComponent,
              },
              {
                path : 'list-dept',
                component: ListDeptComponent,
              },
              {
                path : '',
                redirectTo: 'list-dept',
                pathMatch: 'full',
              },
            ],
          },
        ],
      },
      {
        path : 'user-role',
        component: UserRolesComponent,
      },
    ],
  },
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
  ],
  exports: [
    RouterModule,
  ],
})
export class FormsRoutingModule {
}

