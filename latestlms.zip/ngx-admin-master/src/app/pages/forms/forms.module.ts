import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import {
  NbActionsModule,
  NbButtonModule,
  NbCardModule,
  NbCheckboxModule,
  NbDatepickerModule, NbIconModule,
  NbInputModule,
  NbRadioModule,
  NbSelectModule,
  NbUserModule,
  NbTabsetModule,
  NbRouteTabsetModule,
  NbStepperModule,
  NbListModule,
  NbAccordionModule,
  NbLayoutModule,
  NbMenuModule,
  NbSearchModule,
  NbSidebarModule,
  NbContextMenuModule,
  NbThemeModule,
  NbTooltipModule,
  NbTableModule,
} from '@nebular/theme';

import { ThemeModule } from '../../@theme/theme.module';
import { FormsRoutingModule } from './forms-routing.module';
import { FormsComponent } from './forms.component';
import { OrgMasterComponent } from './org-master/org-master.component';
import { UserRolesComponent } from './user-roles/user-roles.component';
import { OMLocationComponent } from './org-master/o-m-location/o-m-location.component';
import { OMDepartmentComponent } from './org-master/o-m-department/o-m-department.component';
import { OMEmployeeComponent } from './org-master/o-m-employee/o-m-employee.component';
import { AddLocationComponent } from './org-master/o-m-location/add-location/add-location.component';
import { ListLocationComponent } from './org-master/o-m-location/list-location/list-location.component';
import { RouterModule } from '@angular/router';
import { DemoMaterialModule } from '../../material-module';
import { NbEvaIconsModule } from '@nebular/eva-icons';
import { ChartsModule } from 'ng2-charts';
import { ListEmployeeComponent } from './org-master/o-m-employee/list-employee/list-employee.component';
import { AddEmployeeComponent } from './org-master/o-m-employee/add-employee/add-employee.component';
import { AddDeptComponent } from './org-master/o-m-department/add-dept/add-dept.component';
import { ListDeptComponent } from './org-master/o-m-department/list-dept/list-dept.component';
import { CreatorComponent } from './user-roles/creator/creator.component';
import { ApproverComponent } from './user-roles/approver/approver.component';
import { CoOrdinatorComponent } from './user-roles/co-ordinator/co-ordinator.component';

@NgModule({
  imports: [
    FormsModule,
    RouterModule,
    FormsRoutingModule,
    ReactiveFormsModule,
    ThemeModule,
    NbTabsetModule,
    NbRouteTabsetModule,
    NbStepperModule,
    NbCardModule,
    NbButtonModule,
    NbListModule,
    NbAccordionModule,
    NbUserModule,
    DemoMaterialModule,
    NbDatepickerModule.forRoot(),
    NbActionsModule,
    NbLayoutModule,
    NbMenuModule,
    NbSearchModule,
    NbSidebarModule,
    NbContextMenuModule,
    NbSelectModule,
    NbIconModule,
    NbThemeModule,
    NbEvaIconsModule,
    NbTooltipModule,
    NbTableModule,
    NbCheckboxModule,
    ChartsModule,
    NbInputModule,
    NbRadioModule,
  ],
  declarations: [
    FormsComponent,
    OrgMasterComponent,
    UserRolesComponent,
    OMLocationComponent,
    OMDepartmentComponent,
    OMEmployeeComponent,
    AddLocationComponent,
    ListLocationComponent,
    ListEmployeeComponent,
    AddEmployeeComponent,
    AddDeptComponent,
    ListDeptComponent,
    CreatorComponent,
    ApproverComponent,
    CoOrdinatorComponent,
  ],
})
export class AdminModule { }
