import { Router } from '@angular/router';
import {Component, OnInit, ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';

export interface PeriodicElement {
  emp_id: string;
  address: string;
  emp_name: string;
}
const ELEMENT_DATA: PeriodicElement[] = [
 {
    address: 'hr', emp_name : 'hyderabad',
    emp_id: '50038',
  },
  {
     address: 'hr', emp_name : 'hyderabad',
     emp_id: '50012',
   },
   {
     address: 'hr', emp_name : 'kolkatta',
     emp_id: '46515',
   },
   {
     address: 'developer', emp_name : 'hyderabad',
    emp_id: '6565',
   },
   {
     address: 'hr', emp_name : 'vizag',
     emp_id: '410410',
   },
   {
     address: 'network', emp_name : 'pune',
     emp_id: '00012',
   },
];

@Component({
  selector: 'ngx-list-dept',
  templateUrl: './list-dept.component.html',
  styleUrls: ['./list-dept.component.scss'],
})
export class ListDeptComponent implements OnInit {
  displayedColumns: string[] = [
    'emp_id', 'address', 'emp_name',
     'actions'];
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;

  constructor( private router: Router) {
  }

  ngOnInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  addLocation() {
    this.router.navigate(['./pages/forms/master/add-employee']);
  }

}
