import { Router } from '@angular/router';
import {Component, OnInit, ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';

export interface PeriodicElement {
  emp_id: string;
  address: string;
  emp_name: string;
  org_code: string;
  status: string;
}
const ELEMENT_DATA: PeriodicElement[] = [
 {
   org_code : 'A123', address: 'hr', emp_name : 'hyderabad', status: 'A',
    emp_id: '50038',
  },
  {
    org_code : 'A123', address: 'hr', emp_name : 'hyderabad', status: 'A',
     emp_id: '50012',
   },
   {
    org_code : 'A123', address: 'hr', emp_name : 'kolkatta', status: 'B',
     emp_id: '46515',
   },
   {
    org_code : 'A123', address: 'developer', emp_name : 'hyderabad', status: 'C',
    emp_id: '6565',
   },
   {
    org_code : 'A123', address: 'hr', emp_name : 'vizag', status: 'D',
     emp_id: '410410',
   },
   {
    org_code : 'A123', address: 'network', emp_name : 'pune', status: 'E',
     emp_id: '00012',
   },
];

@Component({
  selector: 'ngx-list-employee',
  templateUrl: './list-employee.component.html',
  styleUrls: ['./list-employee.component.scss'],
})
export class ListEmployeeComponent implements OnInit {

  displayedColumns: string[] = [
    'org_code', 'emp_id', 'address', 'emp_name',
      'status', 'action'];
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;

  constructor( private router: Router) {
  }

  ngOnInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  addLocation() {
    this.router.navigate(['./pages/forms/master/add-employee']);
  }

}
