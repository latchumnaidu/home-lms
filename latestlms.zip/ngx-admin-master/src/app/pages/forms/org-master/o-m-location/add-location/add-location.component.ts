import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NbDialogService } from '@nebular/theme';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'ngx-add-location',
  templateUrl: './add-location.component.html',
  styleUrls: ['./add-location.component.scss'],
})
export class AddLocationComponent implements OnInit {
  locationForm: FormGroup;
  submitted = false;
  constructor(
    private router: Router,
    private dialogService: NbDialogService,
    private fb: FormBuilder,
    private http: HttpClient,
    ) { }

    ngOnInit() {
      this.inItForm();
    }
    inItForm() {
      this.locationForm = this.fb.group({
        org_code: ['', Validators.required],
        address: ['', Validators.required],
        city: ['', Validators.required],
        state: ['', Validators.required],
        country: ['', Validators.required],
        zip: ['', Validators.required],
        telephone: ['', Validators.required],
        email: ['', Validators.required],
      });
    }
    get form() {
      return this.locationForm.controls;
    }
    onSubmit() {
      this.submitted = true;
      // stop here if form is invalid
      if (this.locationForm.invalid) {
          return;
      } else {
        const url = 'http://192.168.0.18/api/owner/register/client/';
        this.http.post(url, this.locationForm.value).subscribe(res => {
        });
      }
    }
    listLocation() {
      this.router.navigate(['./pages/forms/master/list-location']);
    }
}
