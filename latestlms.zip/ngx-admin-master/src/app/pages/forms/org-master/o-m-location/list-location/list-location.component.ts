import { Router } from '@angular/router';
import {Component, OnInit, ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';

export interface PeriodicElement {
  org_code: string;
  address: string;
  city: string;
  state: string;
  country: string;
  zip: string;
  telephone: string;
  email: string;
}
const ELEMENT_DATA: PeriodicElement[] = [
 {
   org_code : 'A123', address: 'hr', city : 'hyderabad', state: 'A',
   country : 'country', zip: '50038', telephone: '099400521', email: '#33',
  },
  {
    org_code : 'A123', address: 'hr', city : 'hyderabad', state: 'A',
    country : 'country', zip: '50012', telephone: '099400521', email: '###',
   },
   {
    org_code : 'A123', address: 'hr', city : 'kolkatta', state: 'B',
    country : 'country', zip: '46515', telephone: '099400521', email: '###',
   },
   {
    org_code : 'A123', address: 'developer', city : 'hyderabad', state: 'C',
    country : 'country', zip: '6565', telephone: '099400521', email: '###',
   },
   {
    org_code : 'A123', address: 'hr', city : 'vizag', state: 'D',
    country : 'india', zip: '410410', telephone: '099400521', email: '###',
   },
   {
    org_code : 'A123', address: 'network', city : 'pune', state: 'E',
    country : 'india', zip: '00012', telephone: '099400521', email: '###',
   },
];

@Component({
  selector: 'ngx-list-location',
  templateUrl: './list-location.component.html',
  styleUrls: ['./list-location.component.scss'],
})
export class ListLocationComponent implements OnInit {

  displayedColumns: string[] = [
    'org_code', 'address', 'city',
     'country', 'state',  'zip', 'telephone', 'email', 'action'];
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;

  constructor( private router: Router) {
  }

  ngOnInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  addLocation() {
    this.router.navigate(['./pages/forms/master/add-location']);
  }

}
