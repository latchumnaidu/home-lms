import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrgMasterComponent } from './org-master.component';

describe('OrgMasterComponent', () => {
  let component: OrgMasterComponent;
  let fixture: ComponentFixture<OrgMasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrgMasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrgMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
