import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NbDialogService } from '@nebular/theme';
import { HttpClient } from '@angular/common/http';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
export interface PeriodicElement {
  emp_id: string;
  telephone: string;
  emp_name: string;
  org_code: string;
  email: string;
}
const ELEMENT_DATA: PeriodicElement[] = [
 {
   org_code : 'A123', telephone: '*****', emp_name : 'hyderabad', email: 'A',
    emp_id: '50038',
  },
  {
    org_code : 'A123', telephone: '*****', emp_name : 'hyderabad', email: 'A',
     emp_id: '50012',
   },
   {
    org_code : 'A123', telephone: '*****', emp_name : 'kolkatta', email: 'B',
     emp_id: '46515',
   },
   {
    org_code : 'A123', telephone: '*****', emp_name : 'hyderabad', email: 'C',
    emp_id: '6565',
   },
   {
    org_code : 'A123', telephone: '*****', emp_name : 'vizag', email: 'D',
     emp_id: '410410',
   },
   {
    org_code : 'A123', telephone: '*****', emp_name : 'pune', email: 'E',
     emp_id: '00012',
   },
];

@Component({
  selector: 'ngx-creator',
  templateUrl: './creator.component.html',
  styleUrls: ['./creator.component.scss'],
})
export class CreatorComponent implements OnInit {
  employeeForm: FormGroup;
  submitted = false;
  displayedColumns: string[] = [
    'org_code', 'emp_id', 'telephone', 'emp_name',
      'email', 'action'];
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  addEmp = false;
  constructor(
    private router: Router,
    private dialogService: NbDialogService,
    private fb: FormBuilder,
    private http: HttpClient,
    ) { }

    ngOnInit() {
      this.inItForm();
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }
    inItForm() {
      this.employeeForm = this.fb.group({
        emp_id: ['', Validators.required],
        telephone: ['', Validators.required],
        emp_name: ['', Validators.required],
        org_code: ['', Validators.required],
        email: ['', Validators.required],
      });
    }
    get form() {
      return this.employeeForm.controls;
    }
    onSubmit() {
      this.submitted = true;
      // stop here if form is invalid
      if (this.employeeForm.invalid) {
          return;
      } else {
        const url = 'http://192.168.0.18/api/owner/register/client/';
        this.http.post(url, this.employeeForm.value).subscribe(res => {
        });
      }
    }
    listLocation() {
      // this.router.navigate(['./pages/forms/master/list-employee']);
      this.addEmp = false;
    }
    applyFilter(filterValue: string) {
      this.dataSource.filter = filterValue.trim().toLowerCase();
      if (this.dataSource.paginator) {
        this.dataSource.paginator.firstPage();
      }
    }
    addLocation() {
      // this.router.navigate(['./pages/forms/master/add-employee']);
      this.addEmp = true;
    }

}
