import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-user-roles',
  templateUrl: './user-roles.component.html',
  styleUrls: ['./user-roles.component.scss']
})
export class UserRolesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
