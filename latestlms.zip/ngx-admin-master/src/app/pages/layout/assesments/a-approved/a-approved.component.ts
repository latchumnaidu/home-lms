import {Component, OnInit, ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';

export interface PeriodicElement {
  training_code: string;
  training_name: string;
  ass_code: string;
  ass_name: string;
  test_type: string;
  assign_qns: string;
  total_qns: string;
  total_dur: string;
  assign_users: string;
  status: string;
}
const ELEMENT_DATA: PeriodicElement[] = [
 {
   training_code : 'A123', training_name: 'hr', ass_code: 'hyderabad', ass_name: 'A',
   test_type : 'test_type', assign_qns: '*****', status: 'active', total_qns: '10',
   total_dur : 'x', assign_users: '***',
  },
  {
    training_code : 'A123', training_name: 'hr', ass_code: 'hyderabad', ass_name: 'A',
    test_type : 'test_type', assign_qns: '*****', status: 'active', total_qns: '11',
    total_dur : 'x', assign_users: '***',
   },
   {
    training_code : 'A123', training_name: 'hr', ass_code: 'kolkatta', ass_name: 'B',
    test_type : 'test_type', assign_qns: '*****', status: 'active', total_qns: '12',
    total_dur : 'x', assign_users: '***',
   },
   {
    training_code : 'A123', training_name: 'developer', ass_code: 'hyderabad', ass_name: 'C',
    test_type : 'test_type', assign_qns: '*****', status: 'active', total_qns: '12',
    total_dur : 'x', assign_users: '***',
   },
   {
    training_code : 'A123', training_name: 'hr', ass_code: 'vizag', ass_name: 'D',
    test_type : 'software', assign_qns: '*****', status: 'active', total_qns: '12',
    total_dur : 'x', assign_users: '***',
   },
   {
    training_code : 'A123', training_name: 'network', ass_code: 'pune', ass_name: 'E',
    test_type : 'hardware', assign_qns: '*****', status: 'active', total_qns: '22',
    total_dur : 'x', assign_users: '***',
   },
];

@Component({
  selector: 'ngx-a-approved',
  templateUrl: './a-approved.component.html',
  styleUrls: ['./a-approved.component.scss'],
})
export class AApprovedComponent implements OnInit {

  displayedColumns: string[] = [
    'training_code', 'training_name', 'ass_code', 'ass_name', 'test_type', 'assign_qns',
       'total_qns', 'total_dur', 'assign_users',  'status', 'action'];
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;

  constructor() {
  }

  ngOnInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }


}
