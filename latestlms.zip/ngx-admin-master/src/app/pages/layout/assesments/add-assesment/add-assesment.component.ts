import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NbDialogService } from '@nebular/theme';
import { HttpClient } from '@angular/common/http';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
export interface PeriodicElement {
  tr_code: string;
  ass_name: string;
  ass_code: string;
  tr_name: string;
}
const ELEMENT_DATA: PeriodicElement[] = [
 {
   ass_code : 'A123', ass_name: '*****',  tr_name: 'A',
    tr_code: '50038',
  },
  {
    ass_code : 'A123', ass_name: '*****',  tr_name: 'A',
     tr_code: '50012',
   },
   {
    ass_code : 'A123', ass_name: '*****', tr_name: 'B',
     tr_code: '46515',
   },
   {
    ass_code : 'A123', ass_name: '*****',  tr_name: 'C',
    tr_code: '6565',
   },
   {
    ass_code : 'A123', ass_name: '*****',  tr_name: 'D',
     tr_code: '410410',
   },
   {
    ass_code : 'A123', ass_name: '*****', tr_name: 'E',
     tr_code: '00012',
   },
];

@Component({
  selector: 'ngx-add-assesment',
  templateUrl: './add-assesment.component.html',
  styleUrls: ['./add-assesment.component.scss'],
})
export class AddAssesmentComponent implements OnInit {
  employeeForm: FormGroup;
  submitted = false;
  displayedColumns: string[] = [
    'tr_code', 'tr_name', 'ass_code', 'ass_name',
     'action'];
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  addEmp = false;
  constructor(
    private router: Router,
    private dialogService: NbDialogService,
    private fb: FormBuilder,
    private http: HttpClient,
    ) { }

    ngOnInit() {
      this.inItForm();
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }
    inItForm() {
      this.employeeForm = this.fb.group({
        tr_code: ['', Validators.required],
        tr_name: ['', Validators.required],
        ass_name: ['', Validators.required],
        ass_code: ['', Validators.required],
      });
    }
    get form() {
      return this.employeeForm.controls;
    }
    onSubmit() {
      this.submitted = true;
      // stop here if form is invalid
      if (this.employeeForm.invalid) {
          return;
      } else {
        const url = 'http://192.168.0.18/api/owner/register/client/';
        this.http.post(url, this.employeeForm.value).subscribe(res => {
        });
      }
    }
    listLocation() {
      // this.router.navigate(['./pages/forms/master/list-employee']);
      this.addEmp = false;
    }
    applyFilter(filterValue: string) {
      this.dataSource.filter = filterValue.trim().toLowerCase();
      if (this.dataSource.paginator) {
        this.dataSource.paginator.firstPage();
      }
    }
    addLocation() {
      // this.router.navigate(['./pages/forms/master/add-employee']);
      this.addEmp = true;
    }

}
