import { Component, OnInit } from '@angular/core';
import { DataShareService } from '../../../../../data-share.service';

@Component({
  selector: 'ngx-all-qn-types',
  templateUrl: './all-qn-types.component.html',
  styleUrls: ['./all-qn-types.component.scss'],
})
export class AllQnTypesComponent implements OnInit {
  selectedOption;
  constructor(private dataShare: DataShareService) { }

  ngOnInit() {
    this.selectedOption = this.dataShare.getQnType();
  }

}
