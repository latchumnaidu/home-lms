import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-matching',
  templateUrl: './matching.component.html',
  styleUrls: ['./matching.component.scss']
})
export class MatchingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
