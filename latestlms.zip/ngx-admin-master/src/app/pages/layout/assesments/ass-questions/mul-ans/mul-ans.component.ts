import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-mul-ans',
  templateUrl: './mul-ans.component.html',
  styleUrls: ['./mul-ans.component.scss']
})
export class MulAnsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
