import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SingleAnsComponent } from './single-ans.component';

describe('SingleAnsComponent', () => {
  let component: SingleAnsComponent;
  let fixture: ComponentFixture<SingleAnsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SingleAnsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SingleAnsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
