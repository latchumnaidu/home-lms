import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { Router } from '@angular/router';
import { NbDialogService } from '@nebular/theme';
import { FormBuilder } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
export interface PeriodicElement {
  tr_code: string;
  tr_name: string;
  job_details: string;
  emp_name: string;
}
const ELEMENT_DATA: PeriodicElement[] = [
 {
  tr_code : '1', tr_name: '***', emp_name: 'xxxx',
  job_details:
   'Lorem Ipsum is simply dummy text of the ',
  },
  {
    tr_code : '2', tr_name: '***', emp_name: 'xxxx',
    job_details:
    'Lorem Ipsum is simply dummy text of the ',
   },
   {
    tr_code : '3', tr_name: '***', emp_name: 'xxxx',
     job_details:
    'Lorem Ipsum is simply dummy text of the ',
   },
   {
    tr_code : '4', tr_name: '***', emp_name: 'xxxx',
    job_details:
    'Lorem Ipsum is simply dummy text of the ',
   },
   {
    tr_code : '5', tr_name: '***', emp_name: 'xxxx',
    job_details:
    'Lorem Ipsum is simply dummy text of the ',
   },
   {
    tr_code : '6', tr_name: '***', emp_name: 'xxxx',
     job_details:
    'Lorem Ipsum is simply dummy text of the ',
   },
];

@Component({
  selector: 'ngx-ass-users',
  templateUrl: './ass-users.component.html',
  styleUrls: ['./ass-users.component.scss'],
})
export class AssUsersComponent implements OnInit {
  displayedColumns: string[] = [
    'tr_code', 'job_details', 'tr_name', 'emp_name', 'action'];
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;

  constructor(   private router: Router,
    private dialogService: NbDialogService,
    private fb: FormBuilder,
    private http: HttpClient) {
  }

  ngOnInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

}
