import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'ngx-assesments',
  templateUrl: './assesments.component.html',
  styleUrls: ['./assesments.component.scss'],
})
export class AssesmentsComponent implements OnInit {
  constructor(
          private router: Router,
    ) { }

    ngOnInit() {
    }
}
