import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { Router } from '@angular/router';
import { NbDialogService } from '@nebular/theme';
import { FormBuilder } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
export interface PeriodicElement {
  sr_no: string;
  description: string;
}
const ELEMENT_DATA: PeriodicElement[] = [
 {
   sr_no : '1', description:
   'Lorem Ipsum is simply dummy text of the printing and typesetting industry Lorem Ipsum has been the industrys',
  },
  {
    sr_no : '2', description:
    'Lorem Ipsum is simply dummy text of the printing and typesetting industry Lorem Ipsum has been the industrys',
   },
   {
    sr_no : '3', description:
    'Lorem Ipsum is simply dummy text of the printing and typesetting industry Lorem Ipsum has been the industrys',
   },
   {
    sr_no : '4',
    description:
    'Lorem Ipsum is simply dummy text of the printing and typesetting industry Lorem Ipsum has been the industrys',
   },
   {
    sr_no : '5', description:
    'Lorem Ipsum is simply dummy text of the printing and typesetting industry Lorem Ipsum has been the industrys',
   },
   {
    sr_no : '6', description:
    'Lorem Ipsum is simply dummy text of the printing and typesetting industry Lorem Ipsum has been the industrys',
   },
];
@Component({
  selector: 'ngx-question-bank',
  templateUrl: './question-bank.component.html',
  styleUrls: ['./question-bank.component.scss'],
})
export class QuestionBankComponent implements OnInit {
  displayedColumns: string[] = [
    'sr_no', 'description', 'action'];
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;

  constructor(   private router: Router,
    private dialogService: NbDialogService,
    private fb: FormBuilder,
    private http: HttpClient) {
  }

  ngOnInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

}
