import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreatMasterComponent } from './creat-master.component';

describe('CreatMasterComponent', () => {
  let component: CreatMasterComponent;
  let fixture: ComponentFixture<CreatMasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreatMasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreatMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
