import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-creat-master',
  templateUrl: './creat-master.component.html',
  styleUrls: ['./creat-master.component.scss'],
})
export class CreatMasterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
