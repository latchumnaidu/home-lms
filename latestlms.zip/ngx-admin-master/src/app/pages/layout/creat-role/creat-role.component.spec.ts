import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreatRoleComponent } from './creat-role.component';

describe('CreatRoleComponent', () => {
  let component: CreatRoleComponent;
  let fixture: ComponentFixture<CreatRoleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreatRoleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreatRoleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
