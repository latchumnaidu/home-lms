import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-creat-role',
  templateUrl: './creat-role.component.html',
  styleUrls: ['./creat-role.component.scss']
})
export class CreatRoleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
